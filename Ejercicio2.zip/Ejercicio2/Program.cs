﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        try
        {

            // Obtener la ruta raíz del proyecto
            string rutaRaiz = AppDomain.CurrentDomain.BaseDirectory;

            // Nombre del archivo en la carpeta raíz
            string nombreArchivo = "original.txt";
            string rutaEntrada = Path.Combine(rutaRaiz, nombreArchivo);

            // Verificar si el archivo existe
            if (!File.Exists(rutaEntrada))
            {
                Console.WriteLine("El archivo no existe. Por favor, verifica la ruta." + "Ruta: " + rutaEntrada);
                return;
            }

            // Solicitar el carácter a agregar al final de cada línea
            Console.Write("Ingrese el carácter que desea agregar al final de cada línea: ");
            char caracter = Console.ReadLine()[0];

            // Leer todas las líneas del archivo
            string[] lineas = File.ReadAllLines(rutaEntrada);

            // Modificar las líneas agregando el carácter
            for (int i = 0; i < lineas.Length; i++)
            {
                lineas[i] += caracter;
            }

            string rutaSalida = "nuevo.txt";

            // Guardar el archivo modificado
            File.WriteAllLines(rutaSalida, lineas);

            Console.WriteLine("El archivo se ha procesado y guardado correctamente.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Se produjo un error: {ex.Message}");
        }
    }
}

//using System;
//using System.IO;

//class Program
//{
//    static void Main(string[] args)
//    {
//        try
//        {
//            // Obtener la carpeta raíz de la solución
//            string rutaEjecucion = AppDomain.CurrentDomain.BaseDirectory;
//            string carpetaSolucion = Directory.GetParent(rutaEjecucion)?.Parent?.Parent?.FullName;

//            if (carpetaSolucion == null)
//            {
//                Console.WriteLine("No se pudo determinar la carpeta de la solución.");
//                return;
//            }

//            // Definir la ruta del archivo a crear
//            string nombreArchivo = "archivo_grande.txt";
//            string rutaArchivo = Path.Combine(carpetaSolucion, nombreArchivo);

//            Console.WriteLine("Creando archivo de 3 millones de líneas...");

//            // Crear el archivo con 3 millones de líneas
//            using (StreamWriter escritor = new StreamWriter(rutaArchivo))
//            {
//                for (int i = 1; i <= 3_000_000; i++)
//                {
//                    escritor.WriteLine($"Esta es la línea número {i}");
//                }
//            }

//            Console.WriteLine($"Archivo creado exitosamente en: {rutaArchivo}");
//        }
//        catch (Exception ex)
//        {
//            Console.WriteLine($"Se produjo un error: {ex.Message}");
//        }
//    }
//}